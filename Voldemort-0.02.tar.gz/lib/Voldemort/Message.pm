package Voldemort::Message;

use Moose::Role;

requires 'write';
requires 'read';
1;
