package Voldemort::Protobuff::Resolver;

use Moose::Role;

requires 'resolve';

1;
